import httpx


class SSEError(httpx.TransportError):
    pass
